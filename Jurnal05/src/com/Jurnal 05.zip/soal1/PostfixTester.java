package com.soal1;

public class PostfixTester {
    public static void main(String[] args) {
        PostfixEval pE = new PostfixEval("3-4/5-6");
    }
}